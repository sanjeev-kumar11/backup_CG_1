
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id VARCHAR(10),
    order_date DATE
);

CREATE TABLE order_details (
    detail_id INT PRIMARY KEY,
    order_id INT,
    product_id VARCHAR(10),
    quantity INT,
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);


-- Insert into orders table
INSERT INTO orders (order_id, customer_id, order_date) VALUES
(101, 'C001', '2025-08-01'),
(102, 'C002', '2025-08-02'),
(103, 'C003', '2025-08-03'),
(104, 'C001', '2025-08-04'),
(105, 'C004', '2025-08-04'),
(106, 'C005', '2025-08-05'),
(107, 'C002', '2025-08-05'),
(108, 'C006', '2025-08-05');

-- Insert into order_details table
INSERT INTO order_details (detail_id, order_id, product_id, quantity) VALUES
(1, 101, 'P001', 2),
(2, 101, 'P002', 1),
(3, 102, 'P003', 5),
(4, 103, 'P001', 3),
(5, 104, 'P004', 2),
(6, 105, 'P002', 4),
(7, 106, 'P005', 1),
(8, 107, 'P003', 2);


select * from orders;
select * from order_details;

select order_id from order_details where quantity > (select AVG(quantity) from order_details);

--select order_id from order_details where quantity > AVG(quantity) ;

--select order_id from order_details where quantity in (select AVG(quantity) from order_details);

drop table order_details;
drop table orders;

--------------------------------------------->


CREATE TABLE customer (
    customer_id VARCHAR(10) PRIMARY KEY,
    customer_name VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(15)
);

CREATE TABLE order_new (
    order_id INT PRIMARY KEY,
    customer_id VARCHAR(10),
    order_date DATE,
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
);



-- Insert into customer table
INSERT INTO customer (customer_id, customer_name, email, phone) VALUES
('C001', 'Amit Sharma', 'amit.sharma@example.com', '9876543210'),
('C002', 'Priya Das', 'priya.das@example.com', '9876543211'),
('C003', 'Rahul Mehta', 'rahul.mehta@example.com', '9876543212'),
('C004', 'Sneha Roy', 'sneha.roy@example.com', '9876543213'),
('C005', 'Vikram Singh', 'vikram.singh@example.com', '9876543214');

-- Insert into orders table
INSERT INTO order_new (order_id, customer_id, order_date) VALUES
(201, 'C001', '2025-08-01'),
(202, 'C002', '2025-08-02'),
(203, 'C003', '2025-08-03'),
(204, 'C001', '2025-08-04'),
(205, 'C004', '2025-08-05');

select * from customer;
select * from order_new;

select customer_name, customer_id from customer where customer_id not in (select customer_id from order_new);

select customer_name, customer_id from customer where not exists (select customer_id from order_new where 
order_new.customer_id = customer.customer_id);

--select customer_id, customer_name from customer left join order_new on order_new.customer_id = customer.customer_id where  order_new.customer_id is null;

--select customer_name, customer_id from customer where count(order_new.customer_id) = 0;

drop table customer cascade;
drop table order_new;

----------------------------------------------------------------------------->


CREATE TABLE users (
    id INT PRIMARY KEY,
    name VARCHAR(100),
    friend_id INT
);


INSERT INTO users (id, name, friend_id) VALUES
(1, 'Amit', NULL),
(2, 'Priya', 1),
(3, 'Rahul', 2),
(4, 'Sneha', NULL),
(5, 'Vikram', 3),
(6, 'Neha', 1),
(7, 'Ravi', 5),
(8, 'Kiran', NULL),
(9, 'Anjali', 2),
(10, 'Manoj', 4);


select * from users;

select f.name, users.name as friend_name from users inner join users as f on users.id = f.friend_id and f.friend_id is not null;

--select f.name, users.name as friend_name from users left join users as f on users.id = f.friend_id and f.friend_id is not null;

drop table users;

------------------------------------------------------------------------>


CREATE TABLE website_logs (
    user_id INT,
    page_id VARCHAR(20)
);


INSERT INTO website_logs (user_id, page_id) VALUES
(1, 'home'),       -- unique
(1, 'home'),       -- duplicate
(2, 'about'),      -- duplicate
(2, 'about'),      -- duplicate
(3, 'contact'),    -- unique
(4, 'home'),       -- duplicate
(4, 'home'),       -- duplicate
(5, 'services'),   -- unique
(6, 'home'),       -- unique
(7, 'about');      -- unique

select * from website_logs;

--select user_id , page_id from website_logs group by user_id , page_id having count(*) >1;

--select user_id , page_id from website_logs w1 inner join website_logs w2 on w1.user_id = w2.user_id and w1.page_id = w2.page_id;

--select w2.user_id , w2.page_id from website_logs w1 inner join website_logs w2 on w1.user_id = w2.user_id and w1.page_id != w2.page_id;

select user_id , page_id from website_logs where user_id not in (select user_id from website_logs group by user_id having count(*)>1 );

drop table website_logs;

---------------------------------------------------------------->


CREATE TABLE course (
    course_id VARCHAR(10) PRIMARY KEY,
    course_name VARCHAR(100),
    department VARCHAR(50)
);

CREATE TABLE registration (
    student_id VARCHAR(10),
    course_id VARCHAR(10),
    semester VARCHAR(20),
    FOREIGN KEY (course_id) REFERENCES course(course_id)
);



INSERT INTO course (course_id, course_name, department) VALUES
('CSE101', 'Introduction to CS', 'Computer Science'),
('MAT201', 'Calculus II', 'Mathematics'),
('PHY101', 'Physics I', 'Physics'),
('ENG101', 'English Literature', 'Humanities'),
('BIO101', 'Biology Basics', 'Biology'),
('CSE202', 'Data Structures', 'Computer Science'),
('MAT101', 'Algebra', 'Mathematics'),
('CHE101', 'Chemistry I', 'Chemistry'),
('HIS101', 'World History', 'History'),
('ECO101', 'Microeconomics', 'Economics');

insert into course values('new','demo','demo');


INSERT INTO registration (student_id, course_id, semester) VALUES
('S001', 'CSE101', 'Fall 2024'),
('S002', 'MAT201', 'Fall 2024'),
('S003', 'PHY101', 'Fall 2024'),
('S004', 'ENG101', 'Fall 2024'),
('S005', 'BIO101', 'Fall 2024'),
('S001', 'CSE202', 'Spring 2025'),
('S002', 'MAT101', 'Spring 2025'),
('S003', 'CHE101', 'Spring 2025'),
('S004', 'HIS101', 'Spring 2025'),
('S005', 'ECO101', 'Spring 2025');

select * from registration;

select * from course;

select course.course_id from course left join registration on course.course_id = registration.course_id where registration.course_id is null;

select course_id from course where  course_id not in (select course_id from registration);

select course_id from course where not exists (select * from registration where course.course_id = registration.course_id);

drop table registration;
drop table course;





