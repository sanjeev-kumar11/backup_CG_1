Feature: Login Feature
Scenario: possitive signup scenario
Given user is on signup page
When user enters username 
And email_id 
And mobile number
And passward 
And select gender
And user clicks on continue button
Then user go to login page 
And user enter email id and password 
And user click on sign in button


