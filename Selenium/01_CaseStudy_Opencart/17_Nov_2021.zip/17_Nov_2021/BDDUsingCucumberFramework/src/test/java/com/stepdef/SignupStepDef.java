package com.stepdef;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SignupStepDef {
	
	WebDriver driver;
	@Given("user is on signup page")
	public void user_is_on_signup_page() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		  ChromeOptions options = new ChromeOptions();
		  options.addArguments("--disable-notifications");
		  driver=new ChromeDriver(options);
		  driver.manage().window().maximize();
		  
		  driver.get("https://www.shoppersstop.com/#");
		  Thread.sleep(500);
		driver.findElement(By.xpath("/html/body/main/header/div[1]/div/div[2]/div[2]/ul/li[2]")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@id=\"member-scroller\"]/div/div[1]/div[1]/div/a")).click();;
		driver.findElement(By.xpath("//body/main[1]/div[12]/div[2]/div[1]/div[1]/div[3]/a[1]")).click();;	
	}
	@When("user enters username")
	public void user_enters_username() {
		driver.findElement(By.id("signupFullName")).sendKeys("sanjeev kumar");
	  
	}
	@When("email_id")
	public void email_id() {
		driver.findElement(By.id("signupEmail")).sendKeys("sanjiv.kumar1@gmail.com");
	}
		
	@When("mobile number")
	public void mobile_number() {
			driver.findElement(By.id("signupMobileNumber")).sendKeys("8210664569");  
	}
	@When("passward")
	public void passward() {
		driver.findElement(By.id("signupPassword")).sendKeys("sanjiv1234");
	  
	}
	@When("select gender")
	public void select_gender() {
    driver.findElements(By.xpath("//input[@type='radio']"));
    driver.findElement(By.id("men")).click();		
	}
	
	 
	@When("user clicks on continue button")
	public void user_clicks_on_continue_button() throws InterruptedException {
		driver.findElement(By.xpath("//body/main[1]/div[13]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/button[1]")).click();
		Thread.sleep(5000);
		// As OTP is not part of automation testing our test case fails here
		driver.findElement(By.id("singupRegisterOtp")).sendKeys("123456");
		Thread.sleep(2000);
		driver.findElement(By.id("otpSubmitBtn")).click();	
		Thread.sleep(4000);
	}
	@Then("user go to login page")
	public void user_go_to_login_page() throws InterruptedException {
		 driver.get("https://www.shoppersstop.com/#");
		  Thread.sleep(500);
			driver.findElement(By.xpath("/html/body/main/header/div[1]/div/div[2]/div[2]/ul/li[2]")).click();
			Thread.sleep(500);
			driver.findElement(By.xpath("//*[@id=\"member-scroller\"]/div/div[1]/div[1]/div/a")).click();
			driver.findElement(By.xpath("//a[text()='Sign in with Email'][@class='signinwithemail']")).click();
       
	}
	@Then("user enter email id and password")
	public void user_enter_email_id_and_password() {
		driver.findElement(By.id("j_username")).sendKeys("sanjiv.kumar11@gmail.com");
	    driver.findElement(By.id("j_password")).sendKeys("sanjiv1234");
		
	}
	@Then("user click on sign in button")
	public void user_click_on_sign_in_button() {
		driver.findElement(By.xpath("//button[@id='loginajax']")).click();
	}
	}

	
