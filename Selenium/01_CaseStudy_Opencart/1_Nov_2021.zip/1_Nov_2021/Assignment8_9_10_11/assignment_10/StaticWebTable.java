package assignment_10;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class StaticWebTable {

	public static void main(String[] args) {
		

		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		
		driver.get("https://demo.guru99.com/test/accessing-nested-table.html");
		List<WebElement> alldetail=driver.findElements(By.xpath("/html/body/center/table"));
		System.out.println("List of table detail is: ");
		
		//to print all detail of table in console
		
		for(WebElement e: alldetail)
		{

     	String tabledetails=alldetail.get(alldetail.indexOf(e)).getText();
		System.out.println(tabledetails);
		}
		

	}

}
