package assignment_11;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Conditional_Methods {

	public static void main(String[] args) {
	

		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		    driver.get("https://selenium08.blogspot.com/2019/07/check-box-and-radio-buttons.html");
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
	
			WebElement checkbox = driver.findElement(By.xpath("//input[@type='checkbox'][1]"));
			//to check whether red checkbox is enabled or not
			
			System.out.println("Red Checkbox is Enabled :  "+checkbox.isEnabled());
			//to check whether red checkbox is selected or not
			
			System.out.println("Red Checkbox is Selected :  "+checkbox.isSelected());
			//to check whether opera radio button is selected or not.
			
			WebElement radio =driver.findElement(By.xpath("//input[@type='radio'][3]"));
			System.out.println("Opera Radio is Selected :  "+radio.isSelected());

	
		driver.close();
		}
	}
		
		
		

