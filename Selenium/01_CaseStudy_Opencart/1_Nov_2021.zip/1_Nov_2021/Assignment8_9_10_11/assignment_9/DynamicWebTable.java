package assignment_9;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DynamicWebTable {
	
	WebDriver driver;

	public DynamicWebTable() {
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	//Loading the Url.
	public void loadUrl() {
		driver.get("https://demo.guru99.com/test/web-table-element.php");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	
	public void searchElement() throws InterruptedException{
		// for name of company
		List<WebElement> name = driver.findElements(By.xpath("//tr/td[1]"));
		// for  identify the group of company
		List<WebElement> group = driver.findElements(By.xpath("//tr/td[2]"));
		// for getting prev. close data
		List<WebElement> prevClose = driver.findElements(By.xpath("//tr/td[3]"));
		// for getting the current price
		List<WebElement> currPrice = driver.findElements(By.xpath("//tr/td[4]"));
		// to check the identity present or not.
		boolean inTable = true; 
		
		// getting searching and printing in console about the data
		for(WebElement e : name)
		{
			if(e.getText().equalsIgnoreCase("Bata India"))
			{
				inTable = false;
				String Group = group.get(name.indexOf(e)).getText();
				String PrevClose = prevClose.get(name.indexOf(e)).getText();
				String CurrPrice = currPrice.get(name.indexOf(e)).getText();
				//Displaying into console.
				System.out.println("Bata India is in group "+Group+", Previous closing : "+PrevClose+", Current price "+CurrPrice);				
			}

		}
		//Refreshing the page to get our data
		if(inTable){
			driver.navigate().refresh();
			searchElement();
		}
		
	}
		
		public void closeWebPage() {
	driver.close();
	}
}
