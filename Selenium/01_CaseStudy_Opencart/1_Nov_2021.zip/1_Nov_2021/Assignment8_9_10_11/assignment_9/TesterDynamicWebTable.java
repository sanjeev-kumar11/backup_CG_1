package assignment_9;

public class TesterDynamicWebTable {
	
	public static void main(String[] args) throws InterruptedException {

		DynamicWebTable table = new DynamicWebTable();
		table.loadUrl();
		table.searchElement();
		table.closeWebPage();
	}

}

	
	
	


