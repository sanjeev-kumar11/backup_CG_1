package assignment6;

public class TesterHandling {

	public static void main(String[] args) throws InterruptedException {
		
		WindowHandling wh=new WindowHandling();
		wh.loadingSections();
		wh.openSectionTab();
		wh.switchToWindow();
			
	}

}
