package assignment6;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowHandling{
	 WebDriver driver;
	 
	 public WindowHandling()
	 {
		 System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		 driver=new ChromeDriver();
	 }
	 
	 public void loadingSections() {
		 
		 driver.manage().window().maximize(); 
		driver.get("https://www.shoppersstop.com/");
	}
	 
	 public void openSectionTab()
	 {
	 // open the particular section in new tab
	 WebElement men=driver.findElement(By.xpath("/html/body/main/nav/div[1]/div/ul/li[1]/a"));
     men.sendKeys(Keys.chord(Keys.CONTROL,Keys.RETURN));
     
     WebElement x=driver.findElement(By.xpath("/html/body/main/nav/div[1]/div/ul/li[2]/a"));
     x.sendKeys(Keys.chord(Keys.CONTROL,Keys.RETURN));
     
     WebElement y=driver.findElement(By.xpath("/html/body/main/nav/div[1]/div/ul/li[3]/a"));
     y.sendKeys(Keys.chord(Keys.CONTROL,Keys.RETURN));
     
     WebElement m=driver.findElement(By.xpath("/html/body/main/nav/div[1]/div/ul/li[4]/a"));
     m.sendKeys(Keys.chord(Keys.CONTROL,Keys.RETURN));
     
     WebElement me=driver.findElement(By.xpath("/html/body/main/nav/div[1]/div/ul/li[5]/a"));
     me.sendKeys(Keys.chord(Keys.CONTROL,Keys.RETURN));
	 }

	 public void switchToWindow() throws InterruptedException {

	 // all the handles of opened windows
	 ArrayList<String> allwin=new ArrayList<String>(driver.getWindowHandles());

     driver.switchTo().window(allwin.get(0));
	 Thread.sleep(2000);
	 System.out.println(driver.getTitle());
	 
	 driver.switchTo().window(allwin.get(1));
	 Thread.sleep(4000);
	 System.out.println(driver.getTitle());
	 
	 driver.switchTo().window(allwin.get(2));
	 Thread.sleep(6000);
	 System.out.println(driver.getTitle());
	 
	 driver.switchTo().window(allwin.get(3));
	 Thread.sleep(8000);
	 System.out.println(driver.getTitle());
	 
	 driver.switchTo().window(allwin.get(4));
	 Thread.sleep(10000);
	 System.out.println(driver.getTitle());
	  
	 }	 
	 
}