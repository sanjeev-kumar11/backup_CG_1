package assignment7;

public class AlertTester {

	public static void main(String[] args) throws InterruptedException {
		
		HandlingAlerts hs=new HandlingAlerts();
		hs.alertBox();
		hs.handlingAlerts();
		hs.AlertWithOk();
		hs.handlingAlertsWithOk();
		hs.alertWithText();

}
}