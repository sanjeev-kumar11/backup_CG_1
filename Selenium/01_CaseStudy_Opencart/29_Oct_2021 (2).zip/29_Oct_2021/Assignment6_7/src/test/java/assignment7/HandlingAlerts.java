package assignment7;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlerts {
	
	
	WebDriver driver;
	
	public HandlingAlerts()
	{
		// load driver
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		driver=new ChromeDriver();
	}
	
	public void alertBox()
	{
		// maximizing the window and loading the url
		driver.manage().window().maximize();
	driver.get("http://demo.automationtesting.in/Alerts.html");
	// clicking in button
	driver.findElement(By.xpath("//*[@id=\"OKTab\"]/button")).click();
	}
	
	public void handlingAlerts() throws InterruptedException {
	// alert button suggestion accepted/dismiss	
		Alert aler=driver.switchTo().alert();
		System.out.println(aler.getText());
		Thread.sleep(3000);
		//alert accepted
		aler.accept();  // ok
		}
	
	public void AlertWithOk() throws InterruptedException{
	driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/ul/li[2]/a")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id=\"CancelTab\"]/button")).click();
	}
	
	public void handlingAlertsWithOk() throws InterruptedException {
	Alert aler=driver.switchTo().alert();
	System.out.println(aler.getText());		
	Thread.sleep(4000);
	//aler.dismiss();
	aler.accept();  //ok
	Thread.sleep(3000);
	}
	
	public void alertWithText() throws InterruptedException
	{
		// loading alert box
		driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
		driver.findElement(By.xpath("//button[contains(text(),'click the button to demonstrate the prompt box')]")).click();
		Alert alertText = driver.switchTo().alert();
		Thread.sleep(4000);
		// entering string in alert box
		alertText.sendKeys("Sanjeev");
		System.out.println(alertText.getText());
		alertText.accept();
	}
}

