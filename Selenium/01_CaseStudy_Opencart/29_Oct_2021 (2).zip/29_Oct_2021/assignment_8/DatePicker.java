package assignment_8;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DatePicker {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.get("https://www.path2usa.com/travel-companions");
        
		// travel from
		WebElement from=driver.findElement(By.id("travel_from"));
		from.click();
		from.sendKeys("Alexandria International Airport (Louisiana) (AEX) Alexandria");
		
		//travel to
		WebElement to=driver.findElement(By.id("travel_to"));
		to.click();
		to.sendKeys("Aniak Airport (ANI) Aniak");
		
		//dates from the calender:
		driver.findElement(By.xpath("//input[@id='travel_date']")).click();
		List<WebElement> dates=driver.findElements(By.className("day"));
		System.out.println("Total Size:"+dates.size());
		int count=dates.size();
		
		
		// to select date of traveling 
		for(int i=0;i<count;i++)
		{
		String text=dates.get(i).getText();
		if(text.equalsIgnoreCase("8"))
		{
		String classname=dates.get(i).getAttribute("class");
		if(classname.equalsIgnoreCase("day")||classname.equalsIgnoreCase("active day"))
		{
		dates.get(i).click();
		break;
		}
		}
		}
		
		//choosing traveling flight in the dropdown list.
		WebElement dropDownListAirline = driver.findElement(By.id("travel_airline")); 
		Select dropDownSelectAirline = new Select(dropDownListAirline);
		dropDownSelectAirline.selectByValue("Air India");
		
		////submitting the value
		WebElement dropDownListLang = driver.findElement(By.id("travel_language")); 
		Select dropDownSelectLang = new Select(dropDownListLang);
		dropDownSelectLang.selectByValue("English");
		
		driver.findElement(By.xpath("//*[@id=\"searchform\"]/div[3]/div[2]/div/button")).click();		

	}

}
