package assignment_12;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class Assign12 {
	
	// As Shopperstop web page is not working properly due to notification popup window issue ,
	//  we are doing the same assignment on myntra web page

	public static void main(String[] args) throws InterruptedException {
		
		ChromeOptions o = new ChromeOptions();
		o.addArguments("--disable-notifications");
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver(o);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
        // opening myntra
		driver.get("https://www.myntra.com/");
		
		WebElement w=driver.findElement(By.xpath("//*[@id=\"desktop-header-cnt\"]/div[2]/nav/div/div[3]/div/a"));
	    Actions act=new Actions(driver);
		act.moveToElement(w).build().perform();
		
		WebElement cl=driver.findElement(By.xpath("//*[@id=\"desktop-header-cnt\"]/div[2]/nav/div/div[3]/div/div/div/div/li[5]/ul/li[3]/a"));
		cl.click();
		
	    //filtering boys under Kids watches section
		WebElement boys = driver.findElement(By.xpath("//input[@value='boys,boys girls']"));
		act.moveToElement(boys).click().perform();
				
	    Thread.sleep(3000);
				
	    //filtering brand name as Kool Kidz
	    WebElement brand = driver.findElement(By.xpath("//input[@value='Zoop']"));
		act.click(brand).perform();
				
		//listing out all the watches of boys under the brand Zoop
		List<WebElement> allwatches = driver.findElements(By.xpath("//h4[@class='product-product']"));
		System.out.println("The no of available watches: "+allwatches.size()); //printing the size
				
		//closing the window
		Thread.sleep(3000);
		driver.close(); 		
		}
}