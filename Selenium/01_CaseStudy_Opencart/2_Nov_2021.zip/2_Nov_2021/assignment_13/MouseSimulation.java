package assignment_13;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseSimulation {
	
	WebDriver driver;
	
	public MouseSimulation(){
	// loading the chrome driver
        System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
		
	// loading the mail url in which our execution happen	
		public void loadURL(){
			driver.get("https://demoqa.com/buttons");
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			
		}

		public void DoubleClick() {
			
			//Double click on element
			WebElement ele = driver.findElement(By.xpath("//*[@id=\"doubleClickBtn\"]")); 
			Actions act = new Actions(driver);
			act.doubleClick(ele).perform();
			String click1=ele.getText();
			
            // to verify working properly or not
			if(click1.equals("Double Click Me"))
			{
			System.out.println("Double Click Me excecuted successfully");
			} else {
				System.out.println("INVALID SELECT");
			}
			
		}
		public void RightClick() {
			// right click on element
			WebElement ele = driver.findElement(By.xpath("//*[@id=\"rightClickBtn\"]")); 
			Actions act = new Actions(driver);
			act.contextClick(ele).build().perform();
			String click1=ele.getText();
			
			// to verify working properly or not
			if(click1.equals("Right Click Me"))
			{
			System.out.println("Right Click Me excecuted successfully");
			}else {
				System.out.println("INVALID SELECT");
			}
			
		}
		
		public void ClickMe() {
			// click on element
			WebElement ele = driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/div[3]/button[1]")); 
			ele.click();
			String click3=ele.getText();
			
			// to verify working properly or not
		if(click3.equals("Click Me"))
		{
		System.out.println("Click Me excecuted successfully");
		}else {
			System.out.println("INVALID SELECT");
		}
	}
		
	public void closeAll() throws InterruptedException {
		Thread.sleep(5000);
		driver.close();
	}

		
	

}
