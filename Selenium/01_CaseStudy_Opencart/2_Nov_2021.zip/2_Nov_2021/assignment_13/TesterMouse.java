package assignment_13;

public class TesterMouse {

	public static void main(String[] args) throws InterruptedException {
		
		MouseSimulation ms=new MouseSimulation();
		ms.loadURL();
		ms.DoubleClick();
		ms.RightClick();
		ms.ClickMe();
		ms.closeAll();
		

	}

}
