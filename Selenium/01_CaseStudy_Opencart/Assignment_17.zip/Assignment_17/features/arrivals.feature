@Arrivals
Feature: WebPage Slider ElementVerification
Scenario Outline: Check three Arrivals elements
Given user is on home page
When clicks on shop menu
And clicks on home menu button
And homepage has 3 arrivals images
And clicks the image in the Arrival
Then Image should be clickable and navigate to next page where user can add that book to his basket