package com.arrivals.customexception;

public class InvalidBrowser extends Exception {
	public InvalidBrowser() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidBrowser(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidBrowser(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidBrowser(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidBrowser(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}



