package com.arrivals.page;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.arrivals.customexception.InvalidBrowser;


public class BasePage {

	public WebDriver driver;
	Properties prop;
	String browsername;

	public BasePage() {
		// to initialize the driver: as per config property
		try {
		prop=new Properties();
			prop.load(new FileInputStream("config/config.properties"));
			
		 browsername= prop.getProperty("browser");
		 if (browsername.equalsIgnoreCase("chrome"))
		 {
			 System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
			  driver=new ChromeDriver();
		 }
		 else if(browsername.equalsIgnoreCase("firefox"))
		 {
			 System.setProperty("webdriver.geckodriver.driver", "driver/geckodriver.exe");
			  driver=new FirefoxDriver();
		 }
		 else 
		 {
			 throw new InvalidBrowser("Browser is not supported for esting this page");
		 }	
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidBrowser e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}	
	
	public void init()
	{
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
	}
	public void close() {
		driver.close();
	}
}