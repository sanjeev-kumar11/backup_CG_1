package com.arrivals.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.arrivals.page.*;

public class ArrivalsCheck extends BasePage{
	
	//initiate shop menu link 
			@FindBy(xpath = "//a[text()='Shop']")
			public WebElement shopMenu;
			
			// initiate the homelink
			@FindBy(xpath = "//*[@id=\"content\"]/nav/a")
			public WebElement homeLink;
			
			// arrivals image verification that there is only three arrivals
			@FindBy(xpath = "//img[contains(@class, 'catalog')]")
			public List<WebElement> arrivalImage;
			
//			// click on arrival image to go on next page
//			@FindBy(xpath = "//img[contains(@class, 'attachment-shop_catalog size-shop_catalog wp-post-image')]")
//			public WebElement arrivalNextPage;
			
		
			
			
			
			public ArrivalsCheck() {
				// class constructor
				super();
				init();
				
				//will automatically call driver and find the element 
				
				PageFactory.initElements(driver, this);
				
			}
}
