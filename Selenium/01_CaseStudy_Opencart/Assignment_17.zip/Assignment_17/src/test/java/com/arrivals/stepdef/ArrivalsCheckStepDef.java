package com.arrivals.stepdef;

import org.junit.Assert;

import com.arrivals.pages.ArrivalsCheck;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ArrivalsCheckStepDef {
	ArrivalsCheck ac;
	// go on home page by creating new object 
	@Given("user is on home page")
	public void user_is_on_home_page() {
		ac=new ArrivalsCheck();
	}
	// now second step goes on shop menu
	@When("clicks on shop menu")
	public void clicks_on_shop_menu() {
		ac.shopMenu.click();
		}
	// now again after successfully testing shop menu goes back to home menu
	@When("clicks on home menu button")
	public void clicks_on_home_menu_button() {
		 ac.homeLink.click();
	    }
	// testing 3 arrivals element are there are not
	@When("homepage has {int} arrivals images")
	public void homepage_has_arrivals_images(Integer int3) {
		Assert.assertTrue(ac.arrivalImage.size()==int3);
	}
	// going on navigate to next page where user can add that book to his basket
	@When("clicks the image in the Arrival")
	public void clicks_the_image_in_the_arrival() {
		ac.arrivalImage.get(1).click();
	   }
	
	// next page with correct items are not is tested
	@Then("Image should be clickable and navigate to next page where user can add that book to his basket")
	public void image_should_be_clickable_and_navigate_to_next_page_where_user_can_add_that_book_to_his_basket() {
	
		Assert.assertTrue(ac.driver.getTitle().equalsIgnoreCase("Thinking in HTML � Automation Practice Site"));
		ac.close();
	}
}














