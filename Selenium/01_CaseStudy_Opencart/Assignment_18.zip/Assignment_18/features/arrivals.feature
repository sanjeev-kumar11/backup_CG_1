@Arrivals
Feature: WebPage Slider ElementVerification
Scenario Outline: Check three Arrivals elements
Given user is on home page
When clicks on shop menu
And clicks on home menu button
And homepage has 3 arrivals images
And clicks the image in the Arrival
And Image should be clickable and navigate to next page
And Click on the Add To Basket button
Then user can click on view basket to see item 
And User can view that Book in the Menu item with price