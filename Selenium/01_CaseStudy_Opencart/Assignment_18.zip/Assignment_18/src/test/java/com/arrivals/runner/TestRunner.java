package com.arrivals.runner;


import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="features",
glue = "com.arrivals.stepdef",
//dryRun = true,
plugin= {"pretty"})
// runner page to run all cases 
public class TestRunner {

}